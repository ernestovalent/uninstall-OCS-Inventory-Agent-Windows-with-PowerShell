Write-Host "Inicial Script to uninstall OCS"
# Comprobar la versión del sistema operativo y la compatibilidad de PowerShell
$OSVersion = [Int](Get-CimInstance win32_operatingsystem).BuildNumber
if($OSVersion -gt 6000){
    Write-Host "Windows OS compilation:" $OSVersion
    #Comprobar si OCS se encuentra instalado (3 metodos, servicio, carpeta instalación y carpeta configuración)
    $OCSService = (Get-service -Name "ocs*" | Measure-Object).Count -gt 0
    $OCSInstallx64 = (Test-Path -Path "C:\Program Files\OCS Inventory Agent\OcsSystray.exe") -and (Test-Path -Path "C:\Program Files\OCS Inventory Agent\OCSInventory.exe") -and (Test-Path -Path "C:\Program Files\OCS Inventory Agent\OCSInventory.exe")
    Write-Host $OCSService $OCSInstallx64
}else{
    Write-Host "Windows not compatible."
}